<?php
/**
 * True Stories index — structure matches src/pages/TrueStories.js
 */
$hero_label = gladhat_text('hero_label', 'Gladhat');
$hero_title = gladhat_html('hero_title', 'True <span class="accent">Stories</span>');
$hero_sub   = gladhat_html('hero_subtitle', 'Every project begins with a conversation. Very few follow a perfectly straight line.');

$stories = array();
foreach (gladhat_story_defaults() as $index => $default) {
  $page = get_page_by_path($default['slug']);
  $id   = $page ? (int) $page->ID : 0;
  $stories[] = array(
    'number'   => $id ? (gladhat_meta('story_number', $default['number'], $id) ?: $default['number']) : $default['number'],
    'subtitle' => $id ? (gladhat_meta('story_subtitle', $default['subtitle'], $id) ?: $default['subtitle']) : $default['subtitle'],
    'title'    => $id ? (gladhat_meta('story_card_title', $default['title'], $id) ?: $default['title']) : $default['title'],
    'text'     => $id ? (gladhat_meta('story_card_text', $default['text'], $id) ?: $default['text']) : $default['text'],
    'cta'      => $id ? (gladhat_meta('story_cta', $default['cta'], $id) ?: $default['cta']) : $default['cta'],
    'url'      => $id ? get_permalink($id) : home_url('/' . $default['slug']),
    'img'      => gladhat_image_url($default['img'], $id ?: get_queried_object_id()),
  );
}
?>
    <section class="hero" id="stories-hero" style="min-height: 60vh;">
      <div class="hero__bg"></div>
      <div class="container">
        <div class="hero__content">
          <span class="hero__label"><?php echo $hero_label; ?></span>
          <h1 class="hero__title"><?php echo $hero_title; ?></h1>
          <p class="hero__subtitle">
            <?php echo $hero_sub; ?>
          </p>
        </div>
      </div>
    </section>

    <section class="section" id="stories-intro">
      <div class="container">
        <div class="split reveal" style="align-items: center;">
          <div class="split__text prose" style="max-width: none;">
            <p>The useful moments are often the ones in which a question changes the brief, a hidden strength becomes visible or a complicated idea finally becomes clear.</p>
            <p>That is why I do not think of what follows simply as case studies.</p>
            <p class="highlight-text">They are true stories about the thinking behind the work, what changed along the way and what emerged.</p>
            <p>The industries, challenges and outcomes are different. The underlying approach is consistent:</p>
            <ul style="list-style: none; padding-left: 0; margin-bottom: var(--space-md); font-family: var(--font-heading); color: var(--color-text-muted);">
              <li>✦ Listen carefully & Ask pertinent questions</li>
              <li>✦ Challenge assumptions</li>
              <li>✦ Uncover what is already there</li>
              <li>✦ Connect the dots & Create something that matches the truth</li>
            </ul>
          </div>
          <div class="split__image reveal reveal--delay-2">
            <img src="<?php echo esc_url(gladhat_image_url('stories.png')); ?>" alt="Open Book" loading="lazy" style="border-radius: var(--radius-lg); box-shadow: var(--shadow-glow);">
          </div>
        </div>
      </div>
    </section>

    <section class="section section--alt" id="stories-list">
      <div class="container">

        <div class="section-header reveal">
          <span class="section-header__label">The Work</span>
          <h2 class="section-header__title">Client <span class="accent">Stories</span></h2>
        </div>

        <div style="display: flex; flex-direction: column; gap: var(--space-6xl);">
          <?php foreach ($stories as $index => $s) :
            $is_reverse = $index % 2 !== 0 ? ' split--reverse' : '';
          ?>
      <div class="split<?php echo esc_attr($is_reverse); ?> reveal" style="align-items: center; background: rgba(255,255,255,0.02); padding: var(--space-4xl); border-radius: var(--radius-lg); border: 1px solid rgba(255,255,255,0.05);">
        <div class="split__text prose">
          <div class="story-card__number" style="color: var(--color-accent); font-size: var(--fs-xl); margin-bottom: var(--space-sm); font-family: var(--font-heading);"><?php echo esc_html($s['number']); ?></div>
          <div class="story-card__subtitle" style="font-size: var(--fs-sm); text-transform: uppercase; letter-spacing: var(--ls-widest); color: var(--color-text-muted); margin-bottom: var(--space-xs);"><?php echo esc_html($s['subtitle']); ?></div>
          <h2 style="font-size: var(--fs-2xl); color: var(--color-heading); margin-bottom: var(--space-md);"><?php echo esc_html($s['title']); ?></h2>
          <p style="font-size: var(--fs-lg); color: var(--color-text-muted); margin-bottom: var(--space-lg);"><?php echo esc_html($s['text']); ?></p>
          <a href="<?php echo esc_url($s['url']); ?>" class="story-card__cta" style="color: var(--color-accent); font-weight: var(--fw-medium); text-decoration: none; display: inline-flex; align-items: center; gap: var(--space-xs);">
            <?php echo esc_html($s['cta']); ?> <span class="arrow" style="transition: transform 0.3s ease;">→</span>
          </a>
        </div>
        <div class="split__image reveal reveal--delay-2" style="display: flex; justify-content: center; align-items: center; padding: var(--space-4xl); background: rgba(0,0,0,0.3); border-radius: var(--radius-md);">
          <img src="<?php echo esc_url($s['img']); ?>" alt="<?php echo esc_attr($s['subtitle']); ?> Logo" loading="lazy" style="max-width: 250px; max-height: 250px; object-fit: contain;">
        </div>
      </div>
          <?php endforeach; ?>
        </div>

        <div class="reveal" style="text-align: center; margin-top: var(--space-6xl);">
          <a href="<?php echo esc_url(home_url('/more-stories')); ?>" class="btn btn--outline btn--lg">More Stories <span class="btn-arrow">→</span></a>
        </div>

      </div>
    </section>
