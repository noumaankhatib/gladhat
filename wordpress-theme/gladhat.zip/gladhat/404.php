<?php
get_header();
?>
    <section class="hero" style="min-height: 55vh;">
      <div class="hero__bg"></div>
      <div class="container">
        <div class="hero__content">
          <span class="hero__label">Gladhat</span>
          <h1 class="hero__title">Page not <span class="accent">found</span></h1>
          <p class="hero__subtitle">That address doesn’t match a page on this site.</p>
          <div class="hero__actions">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn--primary btn--lg">Back to Home <span class="btn-arrow">→</span></a>
          </div>
        </div>
      </div>
    </section>
<?php
get_footer();
