<?php
/**
 * Homepage — markup and classes match src/pages/Home.js
 */
get_header();

$brands = array(
  array('file' => 'logos/server_factory.png', 'alt' => 'Server Factory Logo', 'name' => 'Server Factory'),
  array('file' => 'logos/first_light.png', 'alt' => 'First Light Logo', 'name' => 'First Light'),
  array('file' => 'logos/tonbo.png', 'alt' => 'Tonbo Logo', 'name' => 'Tonbo'),
  array('file' => 'logos/ensights.png', 'alt' => 'enSights Logo', 'name' => 'enSights'),
  array('file' => 'logos/provengo.svg', 'alt' => 'Provengo Logo', 'name' => 'Provengo'),
);

$hero_label = gladhat_text('hero_label', 'Gladhat');
$hero_title = gladhat_html('hero_title', 'A different way<br>of <span class="accent">seeing</span>');
$hero_sub   = gladhat_html('hero_subtitle', "Most founders don't need more ideas.<br>
            They need a different perspective.");
?>
    <section class="hero hero--video" id="hero">
      <div class="hero__video-wrap">
        <video autoplay muted loop playsinline id="hero-video">
          <source src="<?php echo esc_url(gladhat_hero_video_url()); ?>" type="video/mp4">
        </video>
        <div class="hero__video-overlay"></div>
      </div>
      <div class="container">
        <div class="hero__content">
          <span class="hero__label"><?php echo $hero_label; ?></span>
          <h1 class="hero__title">
            <?php echo $hero_title; ?>
          </h1>
          <p class="hero__subtitle">
            <?php echo $hero_sub; ?>
          </p>
          <div class="hero__actions">
            <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn--primary btn--lg" id="hero-cta">
              Begin the Conversation <span class="btn-arrow">→</span>
            </a>
            <a href="<?php echo esc_url(home_url('/when-we-should-talk')); ?>" class="btn btn--ghost" id="hero-secondary">
              When we should talk
            </a>
          </div>
        </div>
      </div>
    </section>

    <div class="marquee-container">
      <div class="marquee-track">
        <?php for ($i = 0; $i < 4; $i++) : ?>
          <div class="marquee-item">
            <?php foreach ($brands as $brand) : ?>
            <div class="marquee-brand">
              <img src="<?php echo esc_url(gladhat_image_url($brand['file'])); ?>" alt="<?php echo esc_attr($brand['alt']); ?>" class="marquee-logo-img" loading="lazy">
              <span class="marquee-text"><?php echo esc_html($brand['name']); ?></span>
            </div>
            <span class="marquee-separator">✦</span>
            <?php endforeach; ?>
          </div>
        <?php endfor; ?>
      </div>
    </div>

    <section class="section scrolly-section" id="scrolly" style="padding-top: var(--space-3xl);">
      <div class="container">

        <div class="section-header reveal" style="margin-bottom: var(--space-3xl);">
          <span class="section-header__label">Approach</span>
          <h2 class="section-header__title">The <span class="accent">Philosophy</span></h2>
          <p class="section-header__text">Seeing your business through a different lens.</p>
        </div>

        <div class="scrolly-sync-container" style="display: flex; flex-direction: column; gap: var(--space-6xl);">

          <div class="split reveal" style="align-items: center;">
            <div class="split__text prose">
              <div class="scrolly-number" style="color: var(--color-accent); opacity: 0.5;">01</div>
              <h2 class="scrolly-title">Most founders don't need <span style="color: var(--color-accent);">more ideas</span></h2>
              <p class="scrolly-desc" style="font-size: var(--fs-lg); color: var(--color-text-muted); margin-bottom: var(--space-md);">They already have plenty. What they sometimes need is a different perspective.</p>
              <div class="scrolly-details" style="opacity: 1; max-height: none; overflow: visible;">
                <p>When you live with your business, you tend to stop noticing what confuses potential customers.</p>
                <p>You stop seeing the strengths that make you different.</p>
                <p>You become attached to explanations that no longer help.</p>
                <p>An experienced outside perspective changes that. Not because the outsider knows your business better than you do. But because they <strong>see different things</strong>.</p>
              </div>
            </div>
            <div class="split__image reveal reveal--delay-2">
              <img src="<?php echo esc_url(gladhat_image_url('epic_founders.png')); ?>" alt="Founders Ring" style="border-radius: var(--radius-lg); width: 100%; box-shadow: 0 20px 50px rgba(0,0,0,0.5);" loading="lazy">
            </div>
          </div>

          <div class="split split--reverse reveal" style="align-items: center;">
            <div class="split__text prose">
              <div class="scrolly-number" style="color: var(--color-accent); opacity: 0.5;">02</div>
              <h2 class="scrolly-title">Looking <span style="color: var(--color-accent);">beyond</span></h2>
              <p class="scrolly-desc" style="font-size: var(--fs-lg); color: var(--color-text-muted); margin-bottom: var(--space-md);">We look beyond the obvious to uncover unseen opportunities.</p>
              <div class="scrolly-details" style="opacity: 1; max-height: none; overflow: visible;">
                <p>People often come to me asking for a better website, new messaging, or a marketing campaign.</p>
                <p>Sometimes that's exactly what they need. But often, those requests are symptoms rather than the real challenge.</p>
                <ul style="list-style: none; padding-left: 0; margin-bottom: var(--space-md); font-family: var(--font-heading);">
                  <li style="color: var(--color-text-muted);">✦ What makes customers choose you?</li>
                  <li style="color: var(--color-text-muted);">✦ What have you stopped noticing?</li>
                  <li style="color: var(--color-text-muted);">✦ What assumptions are shaping your decisions?</li>
                </ul>
              </div>
            </div>
            <div class="split__image reveal reveal--delay-2">
              <img src="<?php echo esc_url(gladhat_image_url('epic_beyond.png')); ?>" alt="Beyond Portal" style="border-radius: var(--radius-lg); width: 100%; box-shadow: 0 20px 50px rgba(0,0,0,0.5);" loading="lazy">
            </div>
          </div>

          <div class="split reveal" style="align-items: center;">
            <div class="split__text prose">
              <div class="scrolly-number" style="color: var(--color-accent); opacity: 0.5;">03</div>
              <h2 class="scrolly-title"><span style="color: var(--color-accent);">Essence</span></h2>
              <p class="scrolly-desc" style="font-size: var(--fs-lg); color: var(--color-text-muted); margin-bottom: var(--space-md);">We distill complexity into what truly matters.</p>
              <div class="scrolly-details" style="opacity: 1; max-height: none; overflow: visible;">
                <p>I believe every business has a core truth at its centre:</p>
                <ul style="list-style: none; padding-left: 0; margin-bottom: var(--space-md); font-family: var(--font-heading);">
                  <li style="color: var(--color-text-muted);">— The things it does exceptionally well.</li>
                  <li style="color: var(--color-text-muted);">— The things customers value most.</li>
                  <li style="color: var(--color-text-muted);">— The things competitors can't easily copy.</li>
                </ul>
                <p>The work isn't to invent something new. It's to uncover what's already there and express it with clarity.</p>
              </div>
            </div>
            <div class="split__image reveal reveal--delay-2">
              <img src="<?php echo esc_url(gladhat_image_url('epic_essence.png')); ?>" alt="Essence Sphere" style="border-radius: var(--radius-lg); width: 100%; box-shadow: 0 20px 50px rgba(0,0,0,0.5);" loading="lazy">
            </div>
          </div>

          <div class="split split--reverse reveal" style="align-items: center;">
            <div class="split__text prose">
              <div class="scrolly-number" style="color: var(--color-accent); opacity: 0.5;">04</div>
              <h2 class="scrolly-title"><span style="color: var(--color-accent);">Connecting</span></h2>
              <p class="scrolly-desc" style="font-size: var(--fs-lg); color: var(--color-text-muted); margin-bottom: var(--space-md);">We connect ideas, people, and possibilities to create momentum.</p>
              <div class="scrolly-details" style="opacity: 1; max-height: none; overflow: visible;">
                <p>I naturally connect ideas that don't always seem related.</p>
                <div style="display: flex; flex-wrap: wrap; gap: var(--space-xs); margin: var(--space-sm) 0;">
                  <span style="border: 1px solid rgba(212,165,116,0.3); padding: 4px 8px; border-radius: 4px; font-size: 11px; color: var(--color-accent);">Psychology</span>
                  <span style="border: 1px solid rgba(212,165,116,0.3); padding: 4px 8px; border-radius: 4px; font-size: 11px; color: var(--color-accent);">Positioning</span>
                  <span style="border: 1px solid rgba(212,165,116,0.3); padding: 4px 8px; border-radius: 4px; font-size: 11px; color: var(--color-accent);">Commercial</span>
                </div>
                <p>The deliverable is never the starting point. The thinking is.</p>
              </div>
            </div>
            <div class="split__image reveal reveal--delay-2">
              <img src="<?php echo esc_url(gladhat_image_url('epic_connecting.png')); ?>" alt="Connecting Constellations" style="border-radius: var(--radius-lg); width: 100%; box-shadow: 0 20px 50px rgba(0,0,0,0.5);" loading="lazy">
            </div>
          </div>

          <div class="split reveal" style="align-items: center;">
            <div class="split__text prose">
              <div class="scrolly-number" style="color: var(--color-accent); opacity: 0.5;">05</div>
              <h2 class="scrolly-title"><span style="color: var(--color-accent);">Curiosity</span></h2>
              <p class="scrolly-desc" style="font-size: var(--fs-lg); color: var(--color-text-muted); margin-bottom: var(--space-md);">We stay endlessly curious to keep fueling growth and innovation.</p>
              <div class="scrolly-details" style="opacity: 1; max-height: none; overflow: visible;">
                <p>The best ideas rarely arrive because someone tries to be clever.</p>
                <p>They emerge from genuine curiosity. From wondering what might have been overlooked.</p>
                <p>I want to understand before trying to persuade.</p>
              </div>
            </div>
            <div class="split__image reveal reveal--delay-2">
              <img src="<?php echo esc_url(gladhat_image_url('epic_curiosity.png')); ?>" alt="Curiosity Star" style="border-radius: var(--radius-lg); width: 100%; box-shadow: 0 20px 50px rgba(0,0,0,0.5);" loading="lazy">
            </div>
          </div>

        </div>
      </div>
    </section>

    <section class="section" id="home-whatif" style="padding: var(--space-6xl) 0;">
      <div class="container">
        <div class="split reveal" style="align-items: center;">
          <div class="split__text prose" style="max-width: none;">
            <h2 style="font-size: var(--fs-4xl); line-height: 1.1; margin-bottom: var(--space-xl);">What if...</h2>
            <p style="font-size: var(--fs-lg);">What if your biggest opportunity isn't the one you're currently pursuing?</p>
            <p style="font-size: var(--fs-lg);">What if your customers value something different from what you're talking about?</p>
            <p style="font-size: var(--fs-lg);">What if the answer isn't more marketing, but <strong>seeing your business differently</strong>?</p>

            <hr class="separator" style="margin: var(--space-2xl) 0;">

            <p>Those are the conversations I enjoy most.</p>
            <p>Because once the way you see your business changes…</p>
            <p class="highlight-text" style="font-size: var(--fs-xl);">Everything else can change with it.</p>

            <div style="margin-top: var(--space-3xl);">
              <a href="<?php echo esc_url(home_url('/when-we-should-talk')); ?>" class="btn btn--primary btn--lg" id="home-bottom-cta">
                When We Should Talk <span class="btn-arrow">→</span>
              </a>
            </div>
          </div>

          <div class="split__image reveal reveal--delay-2">
            <img src="<?php echo esc_url(gladhat_image_url('whatif.png')); ?>" alt="A brilliant glowing golden portal representing new possibilities" class="floating" style="border-radius: var(--radius-lg); box-shadow: var(--shadow-glow);" loading="lazy">
          </div>
        </div>
      </div>
    </section>
<?php
get_footer();
