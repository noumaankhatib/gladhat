    </main>
    <footer class="site-footer" id="site-footer" role="contentinfo">
      <div class="footer-cta">
        <div class="footer-cta__content">
          <h2 class="footer-cta__title"><?php echo esc_html(get_theme_mod('gladhat_footer_cta_title', 'Ready to see your business from another angle?')); ?></h2>
          <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn--primary btn--lg" id="footer-cta-btn">
            <?php echo esc_html(get_theme_mod('gladhat_footer_cta_label', 'Begin the Conversation')); ?> <span class="btn-arrow">→</span>
          </a>
        </div>
      </div>

      <div class="footer-main">
        <div class="container">
          <div class="footer-grid">
            <div class="footer-brand">
              <a href="<?php echo esc_url(home_url('/')); ?>" class="logo" aria-label="Gladhat — Home">
                <img class="logo__img" src="<?php echo esc_url(gladhat_logo_url()); ?>" alt="Gladhat Logo">
              </a>
              <p class="footer-brand__tagline">
                <?php echo esc_html(get_theme_mod('gladhat_footer_tagline', 'Commercial strategy, positioning and communication for founders who value clear thinking.')); ?>
              </p>
            </div>

            <div class="footer-links">
              <h3 class="footer-links__title">Explore</h3>
              <ul class="footer-links__list">
                <?php foreach (gladhat_nav_items_resolved() as $item) : ?>
                  <li><a href="<?php echo esc_url($item['url']); ?>"><?php echo esc_html($item['label']); ?></a></li>
                <?php endforeach; ?>
              </ul>
            </div>

            <div class="footer-links">
              <h3 class="footer-links__title">Contact</h3>
              <ul class="footer-links__list footer-contact">
                <li>
                  <a href="mailto:<?php echo esc_attr(antispambot(gladhat_email())); ?>" id="footer-email">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                    <?php echo esc_html(gladhat_email()); ?>
                  </a>
                </li>
                <li>
                  <a href="<?php echo gladhat_linkedin(); ?>" target="_blank" rel="noopener noreferrer" id="footer-linkedin">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg>
                    LinkedIn
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div class="footer-bottom">
        <div class="container">
          <p class="footer-bottom__copy"><?php echo esc_html(get_theme_mod('gladhat_copyright', '© 2026 Gladhat')); ?></p>
          <div class="footer-bottom__links">
            <a href="<?php echo esc_url(get_theme_mod('gladhat_legal_privacy', '#')); ?>" id="footer-privacy">Privacy</a>
            <a href="<?php echo esc_url(get_theme_mod('gladhat_legal_terms', '#')); ?>" id="footer-terms">Terms &amp; Conditions</a>
            <a href="<?php echo esc_url(get_theme_mod('gladhat_legal_disclaimer', '#')); ?>" id="footer-disclaimer">Disclaimer</a>
            <a href="<?php echo esc_url(get_theme_mod('gladhat_legal_cookies', '#')); ?>" id="footer-cookies">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
</div>
<?php wp_footer(); ?>
</body>
</html>
